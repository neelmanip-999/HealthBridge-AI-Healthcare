// Inside ChatWindow.jsx, above useEffect(fetchHistory):
const getChatRoomId = (id1, id2) => {
    // Sort the IDs alphabetically to ensure the room name is always consistent
    const sortedIds = [id1, id2].sort();
    return `${sortedIds[0]}-${sortedIds[1]}`;
};

// ... inside ChatWindow component function ...
const roomId = getChatRoomId(currentUserId, partner._id);

// 2. Listen for Incoming Messages & Join Room
useEffect(() => {
    if (!socket || !currentUserId || !partner?._id) return;
    
    // New: Join the specific chat room
    socket.emit('join_room', roomId); 

    const handleReceiveMessage = (message) => {
        // Only update if the message is for this specific chat
        if (
            (message.senderId === currentUserId && message.receiverId === partner._id) ||
            (message.senderId === partner._id && message.receiverId === currentUserId)
        ) {
            setMessages((prev) => [...prev, message]);
        }
    };

    socket.on('receiveMessage', handleReceiveMessage);

    return () => {
        socket.off('receiveMessage', handleReceiveMessage);
        // Optional: Leave the room when component unmounts
        // socket.emit('leave_room', roomId); 
    };
}, [socket, currentUserId, partner._id, roomId]); // Add roomId to dependency array

// ... inside sendMessage function ...
const sendMessage = async (e) => {
    // ... validation checks ...

    const messageData = {
        // ... (other fields) ...
        roomId: roomId, // CRITICAL: Pass the room ID
    };

    socket.emit('sendMessage', messageData);
    setInput('');
};